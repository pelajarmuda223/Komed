import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.komed.komed.Adapter.AdapterBangunan
import com.komed.komed.databinding.ActivityBangunanBinding
import okhttp3.*
import org.json.JSONArray
import org.json.JSONException
import java.io.IOException

class Bangunan : AppCompatActivity() {
    lateinit var binding: ActivityBangunanBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AdapterBangunan
    private var datalist: MutableList<com.komed.komed.DataModel.Bangunan> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBangunanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView = binding.rvBangunan
        adapter = AdapterBangunan(datalist)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fetchData()

    }

    private fun fetchData() {
        val client = OkHttpClient()

        val request = Request.Builder()
            .url("https://localhost:2000/wisata")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("Gagal", e.message.toString())
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.e("Berhasil", response.code.toString())
                    val responseBody = response.body?.string()
                    val dataList = parseDataFromJson(responseBody)
                }
            }
        })
    }

    private fun parseDataFromJson(responseBody: String?): List<com.komed.komed.DataModel.Bangunan> {
        val dataList = mutableListOf<com.komed.komed.DataModel.Bangunan>()
        try {
            val jsonArray = JSONArray(responseBody)
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val id = jsonObject.getInt("id")
                val namaWisata = jsonObject.getString("namaWisata")
                val gambarWisata = jsonObject.getString("gambarWisata")
                val alamatWisata = jsonObject.getString("alamatWisata")
                val deskripsiWisata = jsonObject.getString("deskripsiWisata")
                val rangeHarga = jsonObject.getString("rangeHarga")
                val namaKategori = jsonObject.getString("namaKategori")

                //filter data
                if (namaKategori == "bangunan") {
                    val bangunanItem = com.komed.komed.DataModel.Bangunan(
                        id,
                        namaWisata,
                        gambarWisata,
                        alamatWisata,
                        deskripsiWisata,
                        rangeHarga,
                        namaKategori)

                    dataList.add(bangunanItem)
                }
            }

        } catch (e: JSONException) {
            e.printStackTrace()
        }

        return dataList
    }

}
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.komed.komed.Adapter.AdapterCafeDanResto
import com.komed.komed.databinding.ActivityCafeRestoBinding
import okhttp3.*
import org.json.JSONArray
import org.json.JSONException
import java.io.IOException

class Cafe  : AppCompatActivity() {
    lateinit var binding: ActivityCafeRestoBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AdapterCafeDanResto
    private var datalist: MutableList<com.komed.komed.DataModel.Cafe> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCafeRestoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView = binding.recyclerview
        adapter = AdapterCafeDanResto(datalist)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fetchData()

    }

    private fun fetchData() {
        val client = OkHttpClient()

        val request = Request.Builder()
            .url("https://localhost:2000/wisata")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("Gagal", e.message.toString())
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.e("Berhasil", response.code.toString())
                    val responseBody = response.body?.string()
                    parseDataFromJson(responseBody)
                }
            }
        })
    }

    private fun parseDataFromJson(responseBody: String?): List<com.komed.komed.DataModel.Cafe> {
        val dataList = mutableListOf<com.komed.komed.DataModel.Cafe>()
        try {
            val jsonArray = JSONArray(responseBody)
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val id = jsonObject.getInt("id")
                val namaWisata = jsonObject.getString("namaWisata")
                val gambarWisata = jsonObject.getString("gambarWisata")
                val alamatWisata = jsonObject.getString("alamatWisata")
                val deskripsiWisata = jsonObject.getString("deskripsiWisata")
                val rangeHarga = jsonObject.getString("rangeHarga")
                val namaKategori = jsonObject.getString("namaKategori")

                //filter data
                if (namaKategori == "cafe dan resto") {
                    val bangunanItem = com.komed.komed.DataModel.Cafe(
                        id,
                        namaWisata,
                        gambarWisata,
                        alamatWisata,
                        deskripsiWisata,
                        rangeHarga,
                        namaKategori)

                    dataList.add(bangunanItem)
                }
            }

        } catch (e: JSONException) {
            e.printStackTrace()
        }

        return dataList
    }

}
package com.komed.komed.Adapter

import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.komed.komed.DataModel.Taman
import com.komed.komed.R

class AdapterTaman(private val listTaman : List<Taman>):RecyclerView.Adapter<AdapterTaman.ViewHolder>() {
    class ViewHolder(itemView : View): RecyclerView.ViewHolder(itemView) {
        val imageTaman : ImageView = itemView.findViewById(R.id.image_list3)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_taman_hiburan,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = listTaman.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = listTaman[position]

        Glide.with(holder.imageTaman)
            .load(data.gambarWisata)
            .into(holder.imageTaman)
    }
}
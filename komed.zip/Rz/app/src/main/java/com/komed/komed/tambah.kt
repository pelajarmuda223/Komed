package com.komed.komed

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import com.komed.komed.Activity.CreateUserActivity
import com.komed.komed.databinding.ActivityCreateUserBinding
import com.komed.komed.databinding.ActivityTambahDestinasiBinding
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import java.io.File
import java.io.IOException

@Suppress("DEPRECATION")
class tambah : AppCompatActivity() {

    private lateinit var binding : ActivityTambahDestinasiBinding
    private var gambarPath: String? = null

    companion object {
        const val REQUEST_PICK_IMAGE = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTambahDestinasiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val items = resources.getStringArray(R.array.kategori)
        val spinner = binding.kategori
        val adapterSpinner = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,items)
        spinner.adapter = adapterSpinner

        binding.inputGambar.setOnClickListener{
            ambilGambar()
        }


        binding.imageView4.setOnClickListener {
            onBackPressed()
        }
        binding.btnTambahkan.setOnClickListener {
            val gambarFile = File(gambarPath)
            val dataNama = binding.inputNama.text.toString()
            val dataDesc = binding.inputDesc.text.toString()
            val dataLokasi = binding.inputLokasi.text.toString()
            val dataJam = binding.jam.text.toString()
            val dataKategori = spinner.selectedItem.toString()
            val dataHarga = binding.harga.text.toString()

            uploadToDatabase(dataNama,gambarFile,dataLokasi,dataDesc,dataJam,dataHarga,dataKategori)
        }

    }

    private fun uploadToDatabase(dataNama: String, gambarFile: File, dataLokasi: String, dataDesc: String, dataJam: String, dataHarga: String, dataKategori: String) {
        val client = OkHttpClient()
        val url = "https://jsonplaceholder.typicode.com/posts"
        val requestBody: MultipartBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("namaWisata", dataNama)
            .addFormDataPart(
                "body",
                gambarFile.name,
                RequestBody.create("image/*".toMediaTypeOrNull(), gambarFile)
            )
            .addFormDataPart("alamatWisata",dataLokasi)
            .addFormDataPart("deskripsiWisata",dataDesc)
            .addFormDataPart("jamOperasional",dataJam)
            .addFormDataPart("rangeHarga",dataHarga)
            .addFormDataPart("namaKategori",dataKategori)
            .build()

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback{
            override fun onFailure(call: Call, e: IOException) {
                Log.e("Data Gagal Terkirim",e.message.toString())
            }

            override fun onResponse(call: Call, response: Response) {
                Log.d("Data Berhasil Terkirim",response.code.toString())
            }
        })
    }

    //loading gambar from Dari uri yang didapat
    private fun ambilGambar() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, CreateUserActivity.REQUEST_PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CreateUserActivity.REQUEST_PICK_IMAGE && resultCode == RESULT_OK) {
            val uriGambar = data?.data
            gambarPath = getImagePath(uriGambar)
            laodGambarDariUri(uriGambar)
        }
    }

    private fun getImagePath(uriGambar: Uri?): String? {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val cursor = contentResolver.query(uriGambar!!, projection, null, null, null)

        return if (cursor != null) {
            val columnIndex = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
            cursor.moveToFirst()
            val imagePath = cursor.getString(columnIndex)
            cursor.close()
            imagePath
        } else {
            null
        }
    }

    //loading gambar from Dari uri yang didapat
    private fun laodGambarDariUri(uriGambar: Uri?) {
        val inputStream = contentResolver.openInputStream(uriGambar!!)
        val bitmap = BitmapFactory.decodeStream(inputStream)
        binding.inputGambar.setImageBitmap(bitmap)
    }
}
package com.komed.komed.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.komed.komed.DataModel.Cafe
import com.komed.komed.R

class AdapterCafeDanResto(private val listCafe : List<Cafe>):RecyclerView.Adapter<AdapterCafeDanResto.CafeViewHolder>() {
    class CafeViewHolder(itemView : View):RecyclerView.ViewHolder(itemView) {
        val image : ImageView = itemView.findViewById(R.id.image_list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CafeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_caferesto,parent,false)
        return CafeViewHolder(view)
    }

    override fun getItemCount(): Int = listCafe.size

    override fun onBindViewHolder(holder: CafeViewHolder, position: Int) {
        val data = listCafe[position]

        Glide.with(holder.image)
            .load(data.gambarWisata)
            .into(holder.image)
    }

}
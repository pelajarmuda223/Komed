package com.komed.komed.Activity

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import com.komed.komed.databinding.ActivityCreateUserBinding
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import java.io.File
import java.io.IOException

class CreateUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateUserBinding
    private var gambarPath: String? = null
    private lateinit var sharedPreferences: SharedPreferences

    companion object {
        const val REQUEST_PICK_IMAGE = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("MyPref", MODE_PRIVATE)
        if (sharedPreferences.getBoolean("data_sent", false)) {
            navigateToNextActivity()
            return
        }

        //pick image from gallery
        binding.ivImageProfile.setOnClickListener {
            ambilGambar()
        }

        //submit and next to activity
        binding.btnNext.setOnClickListener {
            val data = binding.edUsername.text.toString()
            if (data.isNotEmpty() && gambarPath != null) {
                val gambarFile = File(gambarPath!!)
                uploadDataWithDatabase(data, gambarFile)
            } else {
                Toast.makeText(
                    this@CreateUserActivity,
                    "Kamu Belum Menginput Username/Gambar",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    //ke activity selanjutnya
    private fun navigateToNextActivity() {
        val intent = Intent(this@CreateUserActivity, Dashboard::class.java)
        startActivity(intent)
    }

    //mengambil gambar dari galeri
    private fun ambilGambar() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_IMAGE && resultCode == RESULT_OK) {
            val uriGambar = data?.data
            gambarPath = getImagePath(uriGambar)
            laodGambarDariUri(uriGambar)
        }
    }

    //loading gambar from Dari uri yang didapat
    private fun laodGambarDariUri(uriGambar: Uri?) {
        val inputStream = contentResolver.openInputStream(uriGambar!!)
        val bitmap = BitmapFactory.decodeStream(inputStream)
        binding.ivImageProfile.setImageBitmap(bitmap)
    }

    //mengambil lokasi file gambar dari storage
    private fun getImagePath(uriGambar: Uri?): String? {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val cursor = contentResolver.query(uriGambar!!, projection, null, null, null)

        return if (cursor != null) {
            val columnIndex = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
            cursor.moveToFirst()
            val imagePath = cursor.getString(columnIndex)
            cursor.close()
            imagePath
        } else {
            null
        }
    }

    //upload ke Database
    private fun uploadDataWithDatabase(inputUsername: String, imageFile: File) {
        val client = OkHttpClient()
        val url = "https://jsonplaceholder.typicode.com/posts"
        val requestBody: MultipartBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("title", inputUsername)
            .addFormDataPart(
                "body",
                imageFile.name,
                RequestBody.create("image/*".toMediaTypeOrNull(), imageFile)
            )
            .build()

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        //melakukan request secara asynchronus
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("Gagal Mengirim", e.message.toString())
            }

            override fun onResponse(call: Call, response: Response) {
                navigateToNextActivity()
                saveDataToPreferences()
            }
        })
    }

    //menyimpan data menggunakan shared preferences
    private fun saveDataToPreferences() {
        val editor = sharedPreferences.edit()
        editor.putBoolean("data_sent", false)
        editor.apply()
    }
}
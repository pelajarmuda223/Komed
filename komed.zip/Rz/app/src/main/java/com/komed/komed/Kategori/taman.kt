import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.komed.komed.Adapter.AdapterTaman
import com.komed.komed.DataModel.Taman
import com.komed.komed.databinding.ActivityTamanHiburanBinding
import okhttp3.*
import org.json.JSONArray
import org.json.JSONException
import java.io.IOException

class taman  : AppCompatActivity() {
    lateinit var binding: ActivityTamanHiburanBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AdapterTaman
    private var datalist: MutableList<Taman> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTamanHiburanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView = binding.recyclerview2
        adapter = AdapterTaman(datalist)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fetchData()

    }

    private fun fetchData() {
        val client = OkHttpClient()

        val request = Request.Builder()
            .url("https://localhost:2000/wisata")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("Gagal", e.message.toString())
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    Log.e("Berhasil", response.code.toString())
                    val responseBody = response.body?.string()
                    parseDataFromJson(responseBody)
                }
            }
        })
    }

    private fun parseDataFromJson(responseBody: String?): List<Taman> {
        val dataList = mutableListOf<Taman>()
        try {
            val jsonArray = JSONArray(responseBody)
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val id = jsonObject.getInt("id")
                val namaWisata = jsonObject.getString("namaWisata")
                val gambarWisata = jsonObject.getString("gambarWisata")
                val alamatWisata = jsonObject.getString("alamatWisata")
                val deskripsiWisata = jsonObject.getString("deskripsiWisata")
                val rangeHarga = jsonObject.getString("rangeHarga")
                val namaKategori = jsonObject.getString("namaKategori")

                //filter data
                if (namaKategori == "cafe dan resto") {
                    val bangunanItem = Taman(
                        id,
                        namaWisata,
                        gambarWisata,
                        alamatWisata,
                        deskripsiWisata,
                        rangeHarga,
                        namaKategori)

                    dataList.add(bangunanItem)
                }
            }

        } catch (e: JSONException) {
            e.printStackTrace()
        }

        return dataList
    }

}
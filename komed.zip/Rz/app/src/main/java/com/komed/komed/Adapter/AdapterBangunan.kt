package com.komed.komed.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.komed.komed.DataModel.Bangunan
import com.komed.komed.R




class AdapterBangunan(private var listDatamodelBangunan: MutableList<Bangunan>):RecyclerView.Adapter<AdapterBangunan.BangunanViewHolder>() {

    class BangunanViewHolder(itemView : View):RecyclerView.ViewHolder(itemView) {
        val gambarBangunan : ImageView = itemView.findViewById(R.id.image_list2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BangunanViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_bangunan,parent,false)
        return BangunanViewHolder(view)
    }

    override fun getItemCount(): Int = listDatamodelBangunan.size

    override fun onBindViewHolder(holder: BangunanViewHolder, position: Int) {
        val data = listDatamodelBangunan[position]

        Glide.with(holder.gambarBangunan)
            .load(data.gambarWisata)
            .into(holder.gambarBangunan)

    }
}
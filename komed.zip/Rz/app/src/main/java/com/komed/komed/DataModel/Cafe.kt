package com.komed.komed.DataModel

data class Cafe (
    val id: Int,
    val namaWisata: String,
    val gambarWisata: String,
    val alamatWisata: String,
    val deskripsiWisata: String,
    val jamOperasional: String,
    val rangeHarga: String
    )
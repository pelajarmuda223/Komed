package com.komed.komed.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import com.komed.komed.*
import com.komed.komed.Kategori.Bangunan
import com.komed.komed.Kategori.Cafe
import com.komed.komed.Kategori.taman


class Dashboard : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dasbord)

        val user1 = findViewById<ImageButton>(R.id.user1)
        user1.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        val tambah1 = findViewById<ImageButton>(R.id.tambahkan)
        tambah1.setOnClickListener {
            val intent = Intent(this, tambah::class.java)
            startActivity(intent)
        }
        val bangunan1 = findViewById<ImageButton>(R.id.bangunan)
        bangunan1.setOnClickListener {
            val intent = Intent(this, Bangunan::class.java)
            startActivity(intent)
        }
        val cafe1 = findViewById<ImageButton>(R.id.cafe)
        cafe1.setOnClickListener {
            val intent = Intent(this, Cafe::class.java)
            startActivity(intent)
        }
        val taman1 = findViewById<ImageButton>(R.id.taman)
        taman1.setOnClickListener {
            val intent = Intent(this, taman::class.java)
            startActivity(intent)
        }


    }


            }

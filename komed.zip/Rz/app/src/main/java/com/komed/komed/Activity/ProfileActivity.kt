package com.komed.komed.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.komed.komed.R

class ProfileActivity : AppCompatActivity() {

    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)

        // Inisialisasi objek mGoogleSignInClient dan sharedPreferences
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)
        val account = GoogleSignIn.getLastSignedInAccount(this)
        val photoUrl = account?.photoUrl

        // Mendapatkan nama pengguna dari objek GoogleSignInAccount
        val name = account?.displayName


        //fotoprofil
        val photo: ImageView = findViewById(R.id.imageAkun)
        Glide.with(this)
            .load(photoUrl)
            .into(photo)


// Tampilkan nama pengguna di TextView pada halaman profil
        val nameTextView = findViewById<TextView>(R.id.textName)
        nameTextView.text = name

        sharedPreferences = getSharedPreferences("KOMED", Context.MODE_PRIVATE)

        // Inisialisasi ImageButton dan tambahkan listener untuk logout
        val logoutButton: ImageButton = findViewById(R.id.buttonOut)
        logoutButton.setOnClickListener {
            mGoogleSignInClient.signOut().addOnCompleteListener {
                val editor = sharedPreferences.edit()
                editor.clear()
                editor.apply()

                val intent = Intent(this, MainActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                finish()
            }
        }
        val backButton: ImageButton = findViewById(R.id.buttonBack)
        backButton.setOnClickListener {
            val intent = Intent(this@ProfileActivity, Dashboard::class.java)
            startActivity(intent)
            finish()
        }
    }
}